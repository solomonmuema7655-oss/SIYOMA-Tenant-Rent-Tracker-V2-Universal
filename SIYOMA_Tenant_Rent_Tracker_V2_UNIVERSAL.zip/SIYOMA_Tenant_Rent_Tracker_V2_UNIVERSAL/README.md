# SIYOMA Tenant & Rent Tracker V2 — Universal Edition

This edition preserves the V2 application core and official SIYOMA launcher artwork while adding a responsive browser/PWA layer for phones, tablets and laptops.

## Supported targets
- Android phone/tablet: existing Android V2 APK remains separate and unchanged.
- Windows, macOS and Linux: use the Universal Edition through a modern browser; it can be installed as a PWA where supported.

## Important architecture rule
The existing Android Gradle project is not replaced. Android-only functions remain in the Android project. The Universal Edition uses the shared HTML/CSS/JavaScript application core and browser APIs where appropriate.

## Local testing
Service workers require HTTPS or localhost. For a quick local test, serve this folder with any simple local web server and open the displayed localhost address in a modern browser.

## Icon preservation
`icons/icon-192.png` is copied byte-for-byte from the existing V2 `mipmap-xxxhdpi/ic_launcher.png` artwork supplied in the Play-ready V2 project. The 48px icon is copied from the existing mdpi launcher asset.

## Next engineering phase
The next phase should add a clean device-adapter layer for notifications, file saving, printing/PDF and other Android-specific services so the Universal Edition matches the Android V2 behavior as closely as each platform permits.
